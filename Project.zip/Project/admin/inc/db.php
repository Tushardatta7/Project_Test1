<?php
	
	$db = mysqli_connect("localhost", "root", "", "ssb280-project");

	if ( $db ){
		// echo "Database Connected";
	}
	else {
		die("MySQL Connection Faild." . mysqli_error($db));
	}

?>